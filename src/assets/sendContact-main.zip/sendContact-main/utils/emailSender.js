const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'azzizzflash@gmail.com',
    pass: 'none hmbw plyy uvte',
  },
});

const sendEmailToAdmin = (contactDetails) => {
  const mailOptions = {
    from: contactDetails.email,
    to: 'azzizzflash@gmail.com',
    subject: '📩 New Contact Message Received',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
          }
          .container {
            max-width: 600px;
            margin: 20px auto;
            background: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          }
          .header {
            background: #007BFF;
            color: white;
            padding: 20px;
            text-align: center;
          }
          .header img {
            max-width: 150px;
            margin-bottom: 10px;
          }
          .header h1 {
            margin: 0;
            font-size: 24px;
          }
          .content {
            padding: 20px;
            color: #333333;
          }
          .content h2 {
            font-size: 20px;
            margin-bottom: 10px;
          }
          .content p {
            font-size: 16px;
            margin-bottom: 15px;
            line-height: 1.6;
          }
          .content table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
          }
          .content table th,
          .content table td {
            text-align: left;
            padding: 10px;
            border: 1px solid #dddddd;
          }
          .footer {
            background: #f8f8f8;
            text-align: center;
            padding: 15px;
            font-size: 14px;
            color: #666666;
          }
          .footer p {
            margin: 0;
          }
          .footer a {
            color: #007BFF;
            text-decoration: none;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <!-- Header -->
          <div class="header">
            <img src="https://via.placeholder.com/150x50?text=Your+Logo" alt="Logo">
            <h1>New Contact Message</h1>
          </div>

          <!-- Content -->
          <div class="content">
            <h2>Hello Admin,</h2>
            <p>You have received a new message from the contact form. Here are the details:</p>
            <table>
              <tr>
                <th>Name:</th>
                <td>${contactDetails.name}</td>
              </tr>
              <tr>
                <th>Prename:</th>
                <td>${contactDetails.prename}</td>
              </tr>
              <tr>
                <th>Email:</th>
                <td>${contactDetails.email}</td>
              </tr>
              <tr>
                <th>Phone:</th>
                <td>${contactDetails.numtel}</td>
              </tr>
            </table>
            <h2>Message:</h2>
            <p>${contactDetails.message}</p>
          </div>

          <!-- Footer -->
          <div class="footer">
            <p>&copy; 2024 Your Company. All rights reserved.</p>
            <p>
              <a href="https://yourcompany.com" target="_blank">Visit Our Website</a>
            </p>
          </div>
        </div>
      </body>
      </html>
    `,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log('Error sending email: ', error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
};

module.exports = sendEmailToAdmin;
